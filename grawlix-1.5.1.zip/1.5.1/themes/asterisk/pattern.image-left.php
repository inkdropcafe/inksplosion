<section class="pattern-image-left" id="{id}">
	<figure><a href="{link}"><img src="{image}" alt="{title}"/></a></figure>
	<div class="content">
		<h3>{title}</h3>
		{content}
	</div>
</section>
