<!-- GRAWLIX TEMPLATE: This comes from snippet.transcript -->
<?php
$transcript = show('transcript');
if ( $transcript ) : ?>
	<h3>Comic transcript</h3>
	<?=$transcript?>
<?php endif;