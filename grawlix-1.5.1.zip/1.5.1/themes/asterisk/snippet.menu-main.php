<!-- GRAWLIX TEMPLATE: This comes from snippet.main-menu -->

<nav class="header__menu" role="navigation">
	<ul>
		<?=show('menu')?>
	</ul>
</nav>
