	<?=snippet('header')?>
<!-- GRAWLIX TEMPLATE: This comes from page.archive -->
		<br class="clear"/>
		<main>
			<article id="archive" class="archive-content">
				<h2><?=show('archive_headline')?></h2>
				<div>
					<?=show('archive_content')?>
				</div>
			</article>
			<?=snippet('archive-nav')?>
			<br class="clearfix"/>
		</main>
	<?=snippet('footer')?>
