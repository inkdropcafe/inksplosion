	</div>
	<footer role="complementary" itemscope itemtype="http://schema.org/CreativeWork" id="site-foot">
		<div>
			<?=show('copyright')?> by <?=show('artist_name')?>&emsp;&#8253;&emsp;Updates <?=show('publish_frequency')?>&emsp;&#8253;&emsp;Powered by <a href="http://www.getgrawlix.com/">The Grawlix CMS</a>
		</div>
	<?=show_ad('slot-1') ?>
	</footer>
	<script src="//code.jquery.com/jquery-2.1.3.min.js"></script>
	<?=show('support_foot')?>
	<?=snippet('googleanalytics')?>
</body>
</html>
