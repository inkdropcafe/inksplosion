	<?=snippet('header')?>
	<!-- template: page.static -->
		<main>
			<article id="static" class="grlx">
				<div>
					<?=show('page_content')?>
				</div>
			</article>
		</main>
	<?=snippet('footer')?>
