<?=snippet('header') ?>
<!-- template: page.static -->
	<main>
		<?=show('page_content') ?>
	</main>
<?=snippet('footer')?>
