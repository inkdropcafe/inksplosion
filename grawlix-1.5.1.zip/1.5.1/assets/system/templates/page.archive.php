<?=snippet('header') ?>
<!-- template: page.archive -->
	<main>
		<h2><?=show('archive_headline')?></h2>
		<?=show('archive_content')?>
	</main>
<?=snippet('footer')?>
