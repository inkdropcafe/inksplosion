<section id="{id}">
	<header><a href="{link}">{heading}</a></header>
	{text}
	<br class="clearfix"/>
</section>
