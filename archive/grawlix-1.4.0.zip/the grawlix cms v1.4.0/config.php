<?php
$setup['db_host'] = '';
$setup['db_user'] = '';
$setup['db_pswd'] = '';
$setup['db_name'] = '';
