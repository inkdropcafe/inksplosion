<!-- GRAWLIX TEMPLATE: This comes from snippet.footer -->

		<footer role="complementary" itemscope itemtype="http://schema.org/CreativeWork" class="container">
			<div>

				<!-- Edit this with fields in the admin panel or write your own copyright statement here. -->
				<?=show('copyright')?> by <?=show('artist_name')?> • Updates <?=show('publish_frequency')?> • Powered by <a href="http://www.getgrawlix.com/">The Grawlix CMS</a>
			</div>

				<?=show_ad('slot-1') ?>
		</footer>
		<?=snippet('googleanalytics')?>
		<?=snippet('project-wonderful')?>

	</body>
</html>
