<section class="pattern-image-right" id="{id}">
	<div class="content">
		<h3>{title}</h3>
		{content}
	</div>
	<figure><img src="{image}" alt="{title}"/></figure>
</section>
