<?php /* Asterisk 2.0 — www.getgrawlix.com */ ?>

<!-- Get the site-wide header. -->
<?=snippet('header')?>
<!-- GRAWLIX TEMPLATE: This comes from page.static -->

		<main class="page__content">
			<?=show('page_content')?>
		</main>

<!-- Get the site-wide footer. -->
<?=snippet('footer')?>
