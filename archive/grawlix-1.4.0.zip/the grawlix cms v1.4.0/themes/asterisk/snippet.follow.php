<!-- GRAWLIX TEMPLATE: This comes from snippet.follow -->
<h3>Follow me</h3>
<div class="share-icons">
<a class="social-icon rss" class="social-icon" href="<?=show('rss')?>"><img src="/themes/asterisk/images/fab/icon-rss.svg" alt="RSS"></a>
<?php
$info = $this->services['follow']; // Get info from database via page class
if ( $info['deviantart'] ) : ?>
<a class="social-icon" href="http://<?=$info['deviantart'] ?>.deviantart.com"><img src="/themes/asterisk/images/fab/icon-deviantart.svg" alt="deviantArt"></a>
<?php endif;
if ( $info['facebook'] ) : ?>
<a class="social-icon" href="https://www.facebook.com/<?=$info['facebook'] ?>"><img src="/themes/asterisk/images/fab/icon-facebook.svg" alt="Facebook"></a>
<?php endif;
if ( $info['googleplus'] ) : ?>
<a class="social-icon" href="https://plus.google.com/+<?=$info['googleplus'] ?>"><img src="/themes/asterisk/images/fab/icon-google-plus.svg" alt="Google Plus"></a>
<?php endif;
if ( $info['instagram'] ) : ?>
<a class="social-icon" href="http://instagram.com/<?=$info['instagram'] ?>"><img src="/themes/asterisk/images/fab/icon-instagram.svg" alt="Instagram"></a>
<?php endif;
if ( $info['linkedin'] ) : ?>
<a class="social-icon" href="http://www.linkedin.com/in/<?=$info['linkedin'] ?>"><img src="/themes/asterisk/images/fab/icon-linkedin.svg" alt="LinkedIn"></a>
<?php endif;
if ( $info['pinterest'] ) : ?>
<a class="social-icon" href="http://www.pinterest.com/<?=$info['pinterest'] ?>/"><img src="/themes/asterisk/images/fab/icon-pinterest.svg" alt="Pinterest"></a>
<?php endif;
if ( $info['tumblr'] ) : ?>
<a class="social-icon" href="http://<?=$info['tumblr'] ?>.tumblr.com/"><img src="/themes/asterisk/images/fab/icon-tumblr.svg" alt="Tumblr"></a>
<?php endif;
if ( $info['twitter'] ) : ?>
<a class="social-icon" href="https://twitter.com/<?=$info['twitter'] ?>"><img src="/themes/asterisk/images/fab/icon-twitter.svg" alt="Twitter"></a>
<?php endif; ?>
</div>
