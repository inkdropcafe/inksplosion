<section id="{id}" class="samewidth transpose">
	<div>{text}</div>
	<figure><img src="{image}" alt="{image}"/></figure>
	<br class="clearfix"/>
</section>
