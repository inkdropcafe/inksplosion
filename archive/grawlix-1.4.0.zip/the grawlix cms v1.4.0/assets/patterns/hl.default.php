<section id="{id}">
	<header><a href="{link}">{heading}</a></header>
	<br class="clearfix"/>
</section>
