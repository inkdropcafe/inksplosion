<section id="{id}" class="alongside transpose">
	<header>{heading}</header>
	<div>{text}</div>
	<br class="clearfix"/>
</section>
